#include "ADC.h"
#include <util/delay.h>

// Calculation user button state.
// Yes, it is strange to use the ADC for the logic operation.
// But I wanted to study the work of ADC.

void ADC_init()
{
    ADMUX = 0b01010000;
    ADCSRA = 0b10001011;
}

uint16_t ADC_result(uint8_t ADC_input_pin)
{
    // Configure pin as ADC input
    ADMUX = ADC_input_pin | (ADMUX & 0b11110000);
    _delay_us(10);
    // Configure ADSC = 1 for start a conversion
    ADCSRA |= 0b01000000;
    // Waiting for end of the conversion
    while ((ADCSRA & 0b00010000) == 0);
    // Reset the flag ADIF
    ADCSRA |= 0b00010000;
    return ADCL|(ADCH<<8);
}
