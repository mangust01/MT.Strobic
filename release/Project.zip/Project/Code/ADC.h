#ifndef ADC_H_INCLUDED
#define ADC_H_INCLUDED

#include <avr/io.h>

void ADC_init();
uint16_t ADC_result(uint8_t ADC_input_pin);

#endif // ADC_H_INCLUDED
