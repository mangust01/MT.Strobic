/*
Author: Ustiugov Ivan
E-mail: johnustyugov@gmail.com
*/

#include <avr/io.h>
#include <util/delay.h>

// My inclusions
#include "ADC.h"

// Shift register hardware definitions
#define SHIFT_DATA 3
#define SHIFT_CLOCK 5
#define SHIFT_LATCH 0 // Using for set values for all shift register pins
#define SHIFT_DATA_PORT PORTB
#define SHIFT_CLOCK_PORT PORTB
#define SHIFT_LATCH_PORT PORTC
#define SHIFT_DATA_DDR DDRB
#define SHIFT_CLOCK_DDR DDRB
#define SHIFT_LATCH_DDR DDRC

// Shift register Data definitions
#define SHR_DATA_HIGH() (SHIFT_DATA_PORT |= (1<<SHIFT_DATA))
#define SHR_DATA_LOW() (SHIFT_DATA_PORT &= (~(1<<SHIFT_DATA)))

// Delays definitions
const int onStateDelayTime = 3; // How long each delay takes ON
const int pictureDelayTime = 50; // How long between each picture or char in message

uint8_t ADC_PIN = 7;
uint8_t STATE = 0;
uint16_t BUTTON_VALUE = 1;

uint8_t VIBRO_PIN = 3;
uint8_t START_DELAY = 0;
uint8_t VIBRO_TOUCHES = 1;

// Pictures in binary representation
uint16_t SPACE_1[] = {
    0b0000000000000000,
};

uint16_t SAD_FACE_13[] = {
    0b0000000000000000,
    0b0000000000000000,
    0b0000000000000100,
    0b0110000000001000,
    0b0110000000010000,
    0b0000000000010000,
    0b0000000000010000,
    0b0000000000010000,
    0b0110000000010000,
    0b0110000000001000,
    0b0000000000000100,
    0b0000000000000000,
    0b0000000000000000,
    };

uint16_t SMILE_13[] = {
    0b0000000000000000,
    0b0000000000000000,
    0b0000000001000000,
    0b0110000000100000,
    0b0110000000010000,
    0b0000000000001000,
    0b0000000000001000,
    0b0000000000001000,
    0b0110000000010000,
    0b0110000000100000,
    0b0000000001000000,
    0b0000000000000000,
    0b0000000000000000,
    };

uint16_t HOLLOW_HEART_18[] = {
    0b0000000000000000,
    0b0000001110000000,
    0b0000010011000000,
    0b0000100000110000,
    0b0000100000010000,
    0b0000100000001000,
    0b0000010000000100,
    0b0000001000000010,
    0b0000000100000001,
    0b0001111000000010,
    0b0110000000000100,
    0b1100000000001000,
    0b1000000000010000,
    0b1000000000100000,
    0b1000000001000000,
    0b0111000110000000,
    0b0001111100000000,
    0b0000000000000000,
};

uint16_t PANDA_FACE_33[] = {
    0b0000000000000000,
    0b0111000000000000,
    0b1111100000000000,
    0b1111100000000000,
    0b1110000000000000,
    0b1100000000000000,
    0b0000000011100000,
    0b0000000111110000,
    0b0000001000001000,
    0b0000010011001100,
    0b0000010111101100,
    0b0000010011001000,
    0b0000001000010000,
    0b0000000111100000,
    0b0000000000000000,
    0b0000000000000010,
    0b0000000000000011,
    0b0000000000000010,
    0b0000000000000000,
    0b0000000111100000,
    0b0000001000010000,
    0b0000010011001000,
    0b0000010111101100,
    0b0000010011001100,
    0b0000001000001000,
    0b0000000111110000,
    0b0000000011100000,
    0b1100000000000000,
    0b1110000000000000,
    0b1111100000000000,
    0b1111100000000000,
    0b0111000000000000,
    0b0000000000000000,
};

void shift_register_init()
{
    // Configure the shift DATA, CLOCK, LATCH pins as outputs
    SHIFT_DATA_DDR |= (1<<SHIFT_DATA);
    SHIFT_CLOCK_DDR |= (1<<SHIFT_CLOCK);
    SHIFT_LATCH_DDR |= (1<<SHIFT_LATCH);
}

void vibrate_init()
{
    // Configure the vibrate sensor pin as input with internal pull-up resistor
    DDRD &= ~(1<<VIBRO_PIN);
    PORTD |= (1<<VIBRO_PIN);
}

void shift_register_pulse()
{
    // Doing the shift clock
    SHIFT_CLOCK_PORT |= (1<<SHIFT_CLOCK); // HIGH level
    SHIFT_CLOCK_PORT &= (~(1<<SHIFT_CLOCK)); // LOW level
}

void shift_register_latch()
{
    // Doing the latch for all pins
    SHIFT_LATCH_PORT |= (1<<SHIFT_LATCH); // HIGH level
    _delay_loop_1(1);
    SHIFT_LATCH_PORT &= (~(1<<SHIFT_LATCH)); // LOW level
    _delay_loop_1(1);
}

/*
Main data transferring function to shift register 74HC595
Two bytes are serially transfered to IC and then latched.
*/
void shift_register_write(uint16_t output_data)
{
    // Send 16 bits serially
    int i;
    for (i = 0; i < 16; i++)
    {
        if (output_data & 0b1000000000000000)
        {
            SHR_DATA_HIGH();
        }
        else
        {
            SHR_DATA_LOW();
        }
        shift_register_pulse();
        output_data = (output_data<<1);
    }
    shift_register_latch();
}

void shift_register_display_gesture(uint16_t pictureToDisplay[], int columns)
{
    int i;
    for (i = 0; i < columns; i++)
    {
        shift_register_write(pictureToDisplay[i]);
        _delay_ms(onStateDelayTime);
    }
    _delay_ms(pictureDelayTime);
}

int main(void)
{
    vibrate_init();
    shift_register_init();
    ADC_init();

    while(1)
    {
        BUTTON_VALUE = ADC_result(ADC_PIN);
        if (BUTTON_VALUE == 0) {
            if (STATE != 4) {
                STATE++;
            } else {
            STATE = 1; // Default case 1 doing
            }
            _delay_ms(200); // Bounce protection
        };

        switch(STATE)
        {
            case 0: shift_register_write(0b0000000000000000); break;
            case 1:
                if ((PIND & 0b00001000) == 0)
                {
                    shift_register_display_gesture(SMILE_13, 13);
                }
                else
                {
                    shift_register_display_gesture(SPACE_1, 1);
                };
                break;
            case 2:
                if ((PIND & 0b00001000) == 0)
                {
                    shift_register_display_gesture(SAD_FACE_13, 13);
                }
                else
                {
                    shift_register_display_gesture(SPACE_1, 1);
                };
                break;
            case 3:
                if ((PIND & 0b00001000) == 0)
                {
                    _delay_ms(20);
                    shift_register_display_gesture(HOLLOW_HEART_18, 18);
                }
                else
                {
                    shift_register_display_gesture(SPACE_1, 1);
                };
                break;
            case 4:
                if ((PIND & 0b00001000) == 0)
                {
                    _delay_ms(20);
                    shift_register_display_gesture(PANDA_FACE_33, 33);
                }
                else
                {
                    shift_register_display_gesture(SPACE_1, 1);
                };
                break;

            default: _delay_us(1);
        }
    }

    return 0;
}
